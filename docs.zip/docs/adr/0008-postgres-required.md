# ADR-0008: PostgreSQL support is mandatory

## Status

Accepted (2026-10-24)

## Context

Sources today include CSV, Parquet, and Postgres. Treating Postgres as “best-effort / later” would undermine the dbt-help and multi-source goals: real warehouses and OLTP mirrors are usually Postgres (or Postgres-compatible).

## Decision

1. **PostgreSQL is a required first-class source** from v1 — same tier as CSV, not optional.  
2. AST step `LoadPostgres { connection_string, schema, table_name }` stays in the canonical contract (`schema` defaults to `public`). See [ADR-0010](0010-postgres-object-picker.md) for catalog browse / object pick.  
3. Runtime preview: DuckDB `postgres` scanner must be **loaded successfully** for the Postgres path; failure is a **hard, actionable error** when the user runs a workspace that includes `LoadPostgres` (not a silent skip).  
4. Extension load is **offline-first** ([ADR-0011](0011-offline-duckdb-extensions.md)): vendored/`LOAD` from disk; no network `INSTALL` unless `DWH_ALLOW_EXTENSION_DOWNLOAD=1`. CSV/Parquet continue if postgres is missing.  
5. dbt export: `LoadPostgres` → `source('postgres_raw', …)` + `sources.yml` (+ `profiles.yml.example` notes for Postgres target where relevant).  
6. UI: “Add Postgres query” is a v1 surface — **connection + catalog object picker**, not free-typed table-only and not CustomSql.  
7. DoD includes a Postgres fixture path (local Postgres or documented docker) in addition to CSV join.

## Consequences

- Docs/DoD no longer list Postgres as “best-effort only”.  
- Spatial may remain best-effort; **postgres may not**.  
- Security: never log connection strings; prefer secret storage later.  
- CI/smoke should cover `LoadPostgres` when a Postgres service is available.
